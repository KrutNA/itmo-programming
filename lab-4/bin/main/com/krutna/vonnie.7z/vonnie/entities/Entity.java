package com.krutna.vonnie.entities;

/** Entity */
public interface Entity {
  public String getName();
}
