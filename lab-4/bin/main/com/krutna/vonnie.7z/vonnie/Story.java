// package com.krutna.vonnie;

// import java.util.List;
// import java.util.Vector;

// public class Story {
//   List<String> parts;

//   public Story() {
//     parts = new Vector<>();
//   }

//   public void add(String part) {
//     parts.add(part);
//   }

//   public List<String> getStory() {
//     return parts;
//   }
// }
